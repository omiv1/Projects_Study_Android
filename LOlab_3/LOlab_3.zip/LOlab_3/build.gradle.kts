

// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.androidApplication) apply false
}

extra["roomVersion"] = "2.2.4"
extra["archLifecycleVersion"] = "2.2.0"
extra["materialVersion"] = "1.1.1"
