package com.example.lolab_3;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

// ElementDao.java
@Dao
public interface ElementDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    void insert(Element element);

    @Query("DELETE FROM table_name")
    void deleteAll();

    @Query("SELECT * FROM table_name ORDER BY column_name_2 ASC")
    LiveData<List<Element>> getAlphabetizedElements();
}