package com.example.lolab_3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ElementListAdapter extends RecyclerView.Adapter<ElementListAdapter.ElementViewHolder> {
    private LayoutInflater mLayoutInflater;
    private List<Element> mElementList;

    public ElementListAdapter(Context context) {
        mLayoutInflater = LayoutInflater.from(context);
        this.mElementList = null;
    }

    @NonNull
    @Override
    public ElementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate your layout here and return a new ElementViewHolder
        View itemView = mLayoutInflater.inflate(R.layout.element_item, parent, false);
        return new ElementViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ElementViewHolder holder, int position) {
        // Bind your data to the ViewHolder here
        if (mElementList != null) {
            Element current = mElementList.get(position);
            // holder.bind(current); // You need to implement this method in your ViewHolder class
        }
    }

    @Override
    public int getItemCount() {
        if (mElementList != null)
            return mElementList.size();
        return 0;
    }

    public void setElementList(List<Element> elementList) {
        this.mElementList = elementList;
        notifyDataSetChanged();
    }

    public void removeAt(int position) {
        mElementList.remove(position);
        notifyItemRemoved(position);
    }



    class ElementViewHolder extends RecyclerView.ViewHolder {
        // Declare your views here

        ElementViewHolder(View itemView) {
            super(itemView);
            // Initialize your views here
        }

        // void bind(Element element) {
        //     // Bind your data to the views here
        // }
    }
}