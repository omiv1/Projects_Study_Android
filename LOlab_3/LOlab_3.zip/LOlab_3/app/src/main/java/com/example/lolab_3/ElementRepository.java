package com.example.lolab_3;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

// ElementRepository.java
public class ElementRepository {
    private ElementDao mElementDao;
    private LiveData<List<Element>> mAllElements;

    ElementRepository(Application application) {
        ElementRoomDatabase db = ElementRoomDatabase.getDatabase(application);
        mElementDao = db.elementDao();
        mAllElements = mElementDao.getAlphabetizedElements();
    }

    LiveData<List<Element>> getAllElements() {
        return mAllElements;
    }

    void deleteAll() {
        ElementRoomDatabase.databaseWriteExecutor.execute(() -> {
            mElementDao.deleteAll();
        });
    }
}