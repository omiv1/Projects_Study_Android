package com.example.lolab_3;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "table_name")
public class Element {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "column_name")
    private long mKolumna;

    @NonNull
    @ColumnInfo(name = "column_name_2")
    private String mKolumna2;

    public Element(@NonNull String kolumna2) {
        this.mKolumna2 = kolumna2;
    }

    // Getter for mKolumna
    public long getKolumna() {
        return mKolumna;
    }

    // Setter for mKolumna
    public void setKolumna(long mKolumna) {
        this.mKolumna = mKolumna;
    }

    // Getter for mKolumna2
    @NonNull
    public String getKolumna2() {
        return mKolumna2;
    }

    // Setter for mKolumna2
    public void setKolumna2(@NonNull String mKolumna2) {
        this.mKolumna2 = mKolumna2;
    }
}