plugins {
    alias(libs.plugins.androidApplication)
}

android {
    namespace = "com.example.lolab_3"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.lolab_3"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {

    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)


    // Room components
    implementation("androidx.room:room-runtime:${rootProject.ext.get("roomVersion")}")
    annotationProcessor("androidx.room:room-compiler:${rootProject.ext.get("roomVersion")}")
    androidTestImplementation("androidx.room:room-testing:${rootProject.ext.get("roomVersion")}")

    // Lifecycle components
    implementation("androidx.lifecycle:lifecycle-extensions:${rootProject.ext.get("archLifecycleVersion")}")
    annotationProcessor("androidx.lifecycle:lifecycle-compiler:${rootProject.ext.get("archLifecycleVersion")}")

    implementation ("com.google.android.material:material:${rootProject.ext.get("materialVersion")}")

}